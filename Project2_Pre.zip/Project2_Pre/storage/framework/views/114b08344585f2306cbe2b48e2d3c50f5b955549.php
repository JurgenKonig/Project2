<!DOCTYPE html>
<html>
    <head>
        <title>Asset <?php echo e($asset->name); ?></title>
    </head>
    <body>
        <h1>Asset <?php echo e($asset->id); ?></h1>
        <ul>
            <li>Name: <?php echo e($asset->name); ?></li>
            <li>Description: <?php echo e($asset->description); ?></li>
            <li>Value: <?php echo e($asset->value); ?> </li>
            <li>Date Purchased: <?php echo e($asset->purchased); ?></li>
        </ul>
    </body>
</html>

<?php /**PATH /var/www/example/resources/views/assets/show.blade.php ENDPATH**/ ?>