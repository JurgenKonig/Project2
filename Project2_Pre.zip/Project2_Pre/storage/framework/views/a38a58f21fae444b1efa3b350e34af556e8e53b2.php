<!DOCTYPE html>
<html>
    <head><title>Inventory</title></head>
    <body>
        
        <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul><br/>
        <?php endif; ?>
        
        <form method="post" action="<?php echo e(route('assets.store')); ?>">
            <?php echo csrf_field(); ?>
            Name: <input type="text" name="name"><br/>
            Description: <input type="text" name="description"><br/>
            Value: <input type="number" name="value"><br/>
            Date Purchased: <input type="date" name="purchased"><br/>
            <button type="submit"> Add to inventory</button>
        </form>
        
    </body>
</html>



<?php /**PATH /var/www/example/resources/views/assets/create.blade.php ENDPATH**/ ?>