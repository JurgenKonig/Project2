<!DOCTYPE html>
<html>
    <head>
        <title>Inventory</title>
    </head>
    <body>
        <?php if(session()->get('success')): ?>
            <?php echo e(session()->get('success')); ?>

        <?php endif; ?>
        <br/>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Value</th>
                <th>Date Purchased</th>
                <th>Action</th>
            </tr>
            <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($asset->id); ?></td>
                <td><a href="<?php echo e(route('assets.show', $asset->id); ?>"></a><?php echo e($asset->name); ?></td>
                <td><?php echo e($asset->description); ?></td>
                <td><?php echo e($asset->value); ?></td>
                <td><?php echo e($asset->purchased); ?></td>
                <td>
                    <a href="<?php echo e(route('assets.edit', $asset->id)); ?>" method="post">Edit</a>
                    <form action="<?php echo e(route('assets.destroy', $asset->id)); ?> " method="post">
                        <?php echo csrf_field(); ?> 
                        <?php echo method_field('DELETE'); ?>
                        <button type='submit'>Delete</button>
                            
                    </form>
                </td>
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </body>
</html>
<?php /**PATH /var/www/example/resources/views/assets/index.blade.php ENDPATH**/ ?>