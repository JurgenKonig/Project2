<!DOCTYPE html>
<html>
    <head>
        <title>Asset Manager</title>
    </head>
    <body>
        <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        </br>
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('assets.update', $asset->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            Name: <input type="text" name="name" value="<?php echo e($asset->name); ?>">
            Description: <input type="text" name="description" value="<?php echo e($asset->description); ?>">
            Value: <input type="number" name="value" value="<?php echo e($asset->value); ?>">
            Date Purchased: <input type="date" name="purchased" value="<?php echo e($asset->purchased); ?>">
            <button type="submit">Update Asset</button>
        </form>
    </body>
</html>
<?php /**PATH /var/www/example/resources/views/assets/edit.blade.php ENDPATH**/ ?>