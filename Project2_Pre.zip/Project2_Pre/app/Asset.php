<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Asset extends Model
{
    protected $fillable = ['name', 'description', 'value', 'purchased'];
    
    /*
    public function populate(){
        $assets = factory(App\Asset::class, 2)->create();
        
        $assetsCount = count($assets) >= 2;
       
        $this.assertTrue($assetsCount);
    }*/
    
}
