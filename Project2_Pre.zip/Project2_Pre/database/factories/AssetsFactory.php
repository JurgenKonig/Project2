<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model;
use Faker\Generator as Faker;

$factory->define(App\Asset::class, function (Faker $faker) {
    return [
        'name' => $faker->word(2),
        'description' => $faker->unique()->sentence(5),
        'value' => $faker->randomDigit,
        'purchased' => $faker->dateTimeThisMonth
    ];
});
