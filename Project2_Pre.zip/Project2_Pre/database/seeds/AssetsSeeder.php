<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class AssetsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        $assets = factory('App\Asset', 2)->create();
        
        //$this->call(AssetsSeeder::class);
        
        /*
        $faker = Faker\Factory::create();
        
        for ($i = 0; $i < 2; $i++){
            App\Asset::create([
                   'name' => $faker->unique()->name,
                   'description' => $faker->unique()->description,
                   'value' => $faker->unique()->value,
                   'purchase' => $faker->unique()->purchased
            ]);
        }*/
    }
}
