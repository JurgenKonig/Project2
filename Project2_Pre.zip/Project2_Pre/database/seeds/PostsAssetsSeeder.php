<?php

use Illuminate\Database\Seeder;

class PostsAssetsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory('App\Asset', 2)->create();
    }
}
